# Koplaxs5Bot
Bot Protect Versi  1 admin dan 5  Bot
# Koplaxs 5 Bot
Koplaxs BOT Protect
Versi TCR
=======================================
Bot Protect TCR Versi 1 admin dan 5 Bot
=======================================
Bot Line Versi Protect Group
-Siapkan 1 Akun Utama Dan 5 Akun Bot

Fungsinya?
Kelebihan :
1.Protect Group Line Pastinya
2.Dapat Menambah Owner,Admin/Staff Kedalam Bot
3.Command Bisa Dipakai oleh Orang Admin
4.Bot Tidak Saling Kick Ketika Ada Yang Terkick
5.Jika Ingin Protect Lebih Dari 1 Group, Kalian Tidak Wajib ada di Semua Group Tersebut

Kelemahan:
1.BOT Tidak Aktif Ketika Bot Induk Tidak ada di Dalam Group


Cara Instal :
- pkg install python -y
- pkg install python2 -y
- pkg install git -y
- git clone https://github.com/koplaxs/Koplaxs5Bot
- pip2 install rsa
- pip2 install thrift==0.9.3
- pip2 install requests

Cara Menjalankan Botnya :
- cd Koplaxs5Bot
- python Koplaxs5Bot.py

Video Tutor :(HP Root)
https://youtu.be/yYu6ZmiM_YI

Video Tutor :(No Root)
https://youtu.be/Iim_uFMrpCU

Ada Pertanyaan?
Add My Line => @hanavy1992

Thanks For :
- Alfathdirk
- Farzain
- Dan Kawan²
================================
Koplaxs & One Piece Team Protect
================================
